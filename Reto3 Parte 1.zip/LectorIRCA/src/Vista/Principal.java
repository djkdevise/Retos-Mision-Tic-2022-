package Vista;

import Modelo.CuerpoDeAgua;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;


/**
 *
 * @author ContaIPUC
 */
public class Principal {
static Interfaz obInterfaz = new Interfaz();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        obInterfaz.setVisible(true);
        
         
      
        
        //[] vectordeCuerpoDeAgua = new CuerpoDeAgua[nunCuerposAgua];
        //String datos;
             
       //or(int i = 0;i<nunCuerposAgua;i++){
        //datos="";
         
        //datos = leer.nextLine();
//        vectordeCuerpoDeAgua[i] = new CuerpoDeAgua(newDatos[0],Integer.parseInt(newDatos[1]),newDatos[2],Double.parseDouble(newDatos[3]));
       // }
        
        
        
        
        ActionListener obClicIngresar = new ActionListener() {
        @Override
         
       
       public void actionPerformed(ActionEvent e) {
            obInterfaz.txtEntradas.append(obInterfaz.txtNombre.getText() + " " +obInterfaz.txtID.getText() + " " +obInterfaz.txtMunicipio.getText() + " " + obInterfaz.txtTipocuerpoAgua.getText()+ " " + obInterfaz.txtTipoAgua.getText() + " " +obInterfaz.txtIrca.getText());
            if (obInterfaz.txtCantidadCuerposAgua.isEnabled()){
             CuerpoDeAgua[] vectordeCuerpoDeAgua = new CuerpoDeAgua[Integer.parseInt(obInterfaz.txtCantidadCuerposAgua.getText())];   
            };
            obInterfaz.txtCantidadCuerposAgua.disable();
            
            
        }
        };obInterfaz.btnIngresar.addActionListener(obClicIngresar);
        
        ActionListener clicProcesar = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                obInterfaz.txtSalidas.append("Hola");
            }
        };
    
        obInterfaz.btnSalida.addActionListener(clicProcesar);
      
       
    }
    
}
