/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author ContaIPUC
 */
public abstract class ObjetoGeografico {

  
    //Atributos
    
   
    private String tipoCuerpoAgua;
    private String tipoAgua;

   
    //Constructor
     
     public ObjetoGeografico() {
    }
    
   
    public ObjetoGeografico(String tipoCuerpoAgua, String tipoAgua) {
        this.tipoCuerpoAgua = tipoCuerpoAgua;
        this.tipoAgua = tipoAgua;
    }
 
   
    public String getTipoCuerpoAgua() {
        return tipoCuerpoAgua;
    }

    public void setTipoCuerpoAgua(String tipoCuerpoAgua) {
        this.tipoCuerpoAgua = tipoCuerpoAgua;
    }

    public String getTipoAgua() {
        return tipoAgua;
    }

    public void setTipoAgua(String tipoAgua) {
        this.tipoAgua = tipoAgua;
    }
    
    

}
