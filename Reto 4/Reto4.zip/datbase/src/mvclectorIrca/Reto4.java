/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mvclectorIrca;

import Controlador.ControladorApp;
import Modelo.ConsultasCuerpoAgua;
import Modelo.CuerpoDeAgua;
import Vista.Interfaz;


/**
 *
 * @author ContaIPUC
 */
public class Reto4 {
    
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     //Creamos Los Bojetos
     //La Interfaz
      Interfaz objInterfaz = new Interfaz();
     //Modelo del Cuerpo de Agua  
      CuerpoDeAgua objModCuerpoAgua = new CuerpoDeAgua();
      //Modelo de Consultas
      ConsultasCuerpoAgua objModC = new ConsultasCuerpoAgua();
     
     ControladorApp objControl = new ControladorApp(objInterfaz, objModCuerpoAgua, objModC);
  } //Final de Main
    
}//Final de la clase
