/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ContaIPUC
 */
public class ConsultasCuerpoAgua {
    
    /*
 * CRUD producto
 * Resive: modelo CuerpoDeAgua
 * Retorna: Boolean
 */
   
 
    public boolean registrar(CuerpoDeAgua ObjModCuerpoAgua){
        
        PreparedStatement ps = null;
        Connection objConn = ConexionBD.conectar();
        
        String sql = "INSERT INTO tblCuerpoDeAgua(id_CuerpoAgua, nombre_CuerpoAgua, municipio_CuerpoAgua, tipoCuerpoAgua, tipoAgua, irca_CuerpoAgua, nivelRiesgo_CuerpoAgua) VALUES (?,?,?,?,?,?,?)";
        
        try{
            
            ps = objConn.prepareStatement(sql);
            ps.setString(1, Integer.toString(ObjModCuerpoAgua.getNumeroID()));
            ps.setString(2, ObjModCuerpoAgua.getNombre());
            ps.setString(3, ObjModCuerpoAgua.getMunicipio());
            ps.setString(4, ObjModCuerpoAgua.getTipoCuerpoAgua());
            ps.setString(5, ObjModCuerpoAgua.getTipoAgua());
            ps.setDouble(6, ObjModCuerpoAgua.getIrca());
            ps.setString(7, ObjModCuerpoAgua.getNivelRiesgo());
            ps.execute();
            return true;
            
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }finally{
            try{
                objConn.close();
                System.out.println("Cerrar conexion registrar");
            }catch(SQLException e){
                System.err.println(e);
            }
        }
    }  

    public boolean modificar(CuerpoDeAgua ObjModCuerpoAgua){
        
        PreparedStatement ps = null;
        Connection objConn = ConexionBD.conectar();
        
        String sql = "UPDATE tblCuerpoDeAgua SET nombre_CuerpoAgua=?, municipio_CuerpoAgua=?, tipoCuerpoAgua=?, tipoAgua=?, irca_CuerpoAgua=? WHERE id_CuerpoAgua=?";
        
        try{
            System.out.println("El ID es: " + ObjModCuerpoAgua.getNumeroID());
            ps = objConn.prepareStatement(sql);
            ps.setString(1, ObjModCuerpoAgua.getNombre());
            ps.setString(2, ObjModCuerpoAgua.getMunicipio());
            ps.setString(3, ObjModCuerpoAgua.getTipoCuerpoAgua());
            ps.setString(4, ObjModCuerpoAgua.getTipoAgua());
            ps.setDouble(5, ObjModCuerpoAgua.getIrca());
            //ps.setString(6, ObjModCuerpoAgua.getNivelRiesgo());
            ps.setString(6, Integer.toString(ObjModCuerpoAgua.getNumeroID()));
            ps.execute();
            
            return true;
            
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }finally{
            try{
                objConn.close();
                System.out.println("Cerrar conexion modificar");
            }catch(SQLException e){
                System.err.println(e);
            }
        }
    }  

    public boolean eliminar(CuerpoDeAgua ObjModCuerpoAgua){
        
        PreparedStatement ps = null;
        Connection objConn = ConexionBD.conectar();
        
        String sql = "DELETE FROM tblCuerpoDeAgua WHERE id_CuerpoAgua=?";
        
        try{
            
            ps = objConn.prepareStatement(sql);  
            ps.setInt(1, ObjModCuerpoAgua.getNumeroID());
            ps.execute();
            
            return true;
            
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }finally{
            try{
                objConn.close();
                System.out.println("Cerrar conexion eliminar");
            }catch(SQLException e){
                System.err.println(e);
            }
        }
    }  

    public boolean buscar(CuerpoDeAgua ObjModCuerpoAgua){
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection objConn = ConexionBD.conectar();
        
        String sql = "SELECT * FROM tblCuerpoDeAgua WHERE id_CuerpoAgua=?";
        
        try{
            
            ps = objConn.prepareStatement(sql);  
            ps.setString(1, Integer.toString(ObjModCuerpoAgua.getNumeroID()));
            rs = ps.executeQuery();
            
            if(rs.getRow() == 0){
                
                ObjModCuerpoAgua.setNumeroID(rs.getInt("id_CuerpoAgua"));
		ObjModCuerpoAgua.setNombre(rs.getString("nombre_CuerpoAgua"));
                ObjModCuerpoAgua.setMunicicipio(rs.getString("municipio_CuerpoAgua"));
                ObjModCuerpoAgua.setTipoCuerpoAgua(rs.getString("tipoCuerpoAgua"));
                ObjModCuerpoAgua.setTipoAgua(rs.getString("tipoAgua"));
                ObjModCuerpoAgua.setIrca(rs.getDouble("irca_CuerpoAgua"));
		ObjModCuerpoAgua.setNivelRiesgo(rs.getDouble("irca_CuerpoAgua"));
               
                return true;
            }

            return false;
            
        }catch(SQLException e){
            System.err.println(e);
            return false;
        }finally{
            try{
                objConn.close();
                System.out.println("Cerrar conexion buscar");
            }catch(SQLException e){
                System.err.println(e);
            }
        }
    }  
    
    public ArrayList<CuerpoDeAgua> consulta(){
        ArrayList<CuerpoDeAgua> objLista = new ArrayList<CuerpoDeAgua>();
       
        objLista.clear();
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection objConn = ConexionBD.conectar();
        
        String sql = "SELECT * FROM tblCuerpoDeAgua";
        
        try{
            
            ps = objConn.prepareStatement(sql);  
            rs = ps.executeQuery();
            
            if(rs.getRow() == 0){
                
                while(rs.next()){
                CuerpoDeAgua ObjModCuerpoAgua = new CuerpoDeAgua();
                ObjModCuerpoAgua.setNumeroID(rs.getInt("id_CuerpoAgua"));
		ObjModCuerpoAgua.setNombre(rs.getString("nombre_CuerpoAgua"));
                ObjModCuerpoAgua.setMunicicipio(rs.getString("municipio_CuerpoAgua"));
                ObjModCuerpoAgua.setTipoCuerpoAgua(rs.getString("tipoCuerpoAgua"));
                ObjModCuerpoAgua.setTipoAgua(rs.getString("tipoAgua"));
                ObjModCuerpoAgua.setIrca(rs.getDouble("irca_CuerpoAgua"));
		ObjModCuerpoAgua.setNivelRiesgo(rs.getDouble("irca_CuerpoAgua"));
                
                objLista.add(ObjModCuerpoAgua);
                    
                }
                
                System.out.println(objLista.size());
                return objLista;
            }

            return objLista;
            
        }catch(SQLException e){
            System.err.println(e);
            return objLista;
        }finally{
            try{
                objConn.close();
                System.out.println("Cerrar conexion consulta");
            }catch(SQLException e){
                System.err.println(e);
            }
        }
    }  
    
    
  
}
