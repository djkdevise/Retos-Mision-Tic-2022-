/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ConsultasCuerpoAgua;
import Modelo.CuerpoDeAgua;
import Vista.Interfaz;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;



/**
 *
 * @author ContaIPUC
 */
//Importante nuestra clase implementa ActionListener
public class ControladorApp implements ActionListener{ 
    //Creamos los atributos que manejara el Controlador
    private Interfaz objInterfaz;
    private CuerpoDeAgua ObjModCuerpoAgua;
    private ConsultasCuerpoAgua objModCconsultas;
    ArrayList<CuerpoDeAgua> objLista;
    
    
      //Decalramos Meteodo constructor del Contralador
    public ControladorApp(Interfaz objInterfaz, CuerpoDeAgua ObjModCuerpoAgua, ConsultasCuerpoAgua objModCconsultas) {
        
        this.objInterfaz = objInterfaz;
        this.ObjModCuerpoAgua = ObjModCuerpoAgua;
        this.objModCconsultas = objModCconsultas;
        
        inicarapp();
        deshabilita(false);
        
    }
    
    //Control de Interfaz y Botones
    public void inicarapp(){
        objInterfaz.setVisible(true);
        objInterfaz.btnIngresar.addActionListener(this);
        objInterfaz.btnObtenerDatos.addActionListener(this);
        objInterfaz.btnProcesar.addActionListener(this);
        objInterfaz.btnBuscar.addActionListener(this);
        objInterfaz.btnEditar.addActionListener(this);
        objInterfaz.btnEliminar.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    	// detectar que boton preciona +++ GUARDAR ++
		if(e.getSource() == objInterfaz.btnIngresar){

			ObjModCuerpoAgua.setNumeroID(Integer.parseInt(objInterfaz.txtID.getText()));
			ObjModCuerpoAgua.setNombre(objInterfaz.txtNombre.getText());
                        ObjModCuerpoAgua.setMunicicipio(objInterfaz.txtMunicipio.getText());
                        ObjModCuerpoAgua.setTipoCuerpoAgua(objInterfaz.txtTipoCuerpoAgua.getText());
                        ObjModCuerpoAgua.setTipoAgua(objInterfaz.txtTipoAgua.getText());
			ObjModCuerpoAgua.setIrca(Double.parseDouble(objInterfaz.txtIRCA.getText()));
			ObjModCuerpoAgua.setNivelRiesgo(Double.parseDouble(objInterfaz.txtIRCA.getText()));

			if(objModCconsultas.registrar(ObjModCuerpoAgua)){

				JOptionPane.showMessageDialog(null, "Registro Guardado");
				limpiar();

			} else {
				JOptionPane.showMessageDialog(null, "Error al Guardar");	
				limpiar();
			}
		}
               
// ++ MODIFICAR ++ 
		if(e.getSource() == objInterfaz.btnEditar){
                        
                        ObjModCuerpoAgua.setNumeroID(Integer.parseInt(objInterfaz.txtID_Buscar_Rest.getText()));
			ObjModCuerpoAgua.setNombre(objInterfaz.txtNombre_Buscar_Rest.getText());
                        ObjModCuerpoAgua.setMunicicipio(objInterfaz.txtMunicipio_Buscar_Rest.getText());
                        ObjModCuerpoAgua.setTipoCuerpoAgua(objInterfaz.txtTipoCuerpoAgua_Buscar_Rest.getText());
                        ObjModCuerpoAgua.setTipoAgua(objInterfaz.txtTipoAgua_Buscar_Rest.getText());
			ObjModCuerpoAgua.setIrca(Double.parseDouble(objInterfaz.txtIRCA_Rest.getText()));
			//ObjModCuerpoAgua.setNivelRiesgo(Double.parseDouble(objInterfaz.txtIRCA_Rest.getText()));
                        
                        
			/*
                        ObjModCuerpoAgua.setNumeroID(Integer.parseInt(objInterfaz.txtID_Buscar.getText()));
			ObjModCuerpoAgua.setCodigo(objInterfaz.txtCodigo.getText());
			ObjModCuerpoAgua.setNombre(objInterfaz.txtNombre.getText());
			ObjModCuerpoAguasetPrecio( Double.parseDouble(objInterfaz.txtPrecio.getText()));
			ObjModCuerpoAguasetCantidad( Integer.parseInt(objInterfaz.txtCantidad.getText()));
                        */
			if(objModCconsultas.modificar(ObjModCuerpoAgua)){

				JOptionPane.showMessageDialog(null, "Registro Modificado");
				//limpiar();

			} else {
				JOptionPane.showMessageDialog(null, "Error al Modificar");	
				//limpiar();
			}
		}
// ++ ELIMINAR ++
		if(e.getSource() == objInterfaz.btnEliminar){

			ObjModCuerpoAgua.setNumeroID(Integer.parseInt(objInterfaz.txtID_Buscar.getText()));

			if(objModCconsultas.eliminar(ObjModCuerpoAgua)){

				JOptionPane.showMessageDialog(null, "Registro Eliminado");
				limpiar();

			} else {
				JOptionPane.showMessageDialog(null, "Error al Eliminar");	
				limpiar();
			}
		}
               
// ++ BUSCAR ++
		if(e.getSource() == objInterfaz.btnBuscar){

			ObjModCuerpoAgua.setNumeroID(Integer.parseInt(objInterfaz.txtID_Buscar.getText()));

			if(objModCconsultas.buscar(ObjModCuerpoAgua)){
                                deshabilita(true);
                                objInterfaz.txtNombre_Buscar_Rest.setText(ObjModCuerpoAgua.getNombre());
				objInterfaz.txtID_Buscar_Rest.setText(String.valueOf(ObjModCuerpoAgua.getNumeroID()));
				objInterfaz.txtMunicipio_Buscar_Rest.setText(ObjModCuerpoAgua.getMunicipio());
				objInterfaz.txtTipoCuerpoAgua_Buscar_Rest.setText(ObjModCuerpoAgua.getTipoCuerpoAgua());
                                objInterfaz.txtTipoAgua_Buscar_Rest.setText(ObjModCuerpoAgua.getTipoAgua());
                                objInterfaz.txtIRCA_Rest.setText(String.valueOf(ObjModCuerpoAgua.getIrca()));
                                objInterfaz.txtID_Buscar_Rest.setEnabled(false);
			} else {
				JOptionPane.showMessageDialog(null, "No se encontro registro");	
				limpiar();
			}
		}
                
    // ++ CONSULTAR ++
		if(e.getSource() == objInterfaz.btnObtenerDatos){
                    
                        objLista = objModCconsultas.consulta();
                         System.out.println(objLista.size());
			if(objLista != null || objLista.size()>0){
                            for (CuerpoDeAgua cuerpoDeAgua : objLista) {
                                objInterfaz.txtaEntrada.append(cuerpoDeAgua.getNombre() + " " + cuerpoDeAgua.getNumeroID() + " " + cuerpoDeAgua.getMunicipio() + " " +cuerpoDeAgua.getTipoCuerpoAgua() + " " + cuerpoDeAgua.getTipoAgua() + " " + cuerpoDeAgua.getIrca() + "\n");  
                            }
                            
			} else {
				JOptionPane.showMessageDialog(null, "No se encontro registro");	
				//limpiar();
			}
		}
                
    // ++ PROCESAR ++       
                if(e.getSource() == objInterfaz.btnProcesar){
                    
                        objLista = objModCconsultas.consulta();
                         System.out.println(objLista.size());
			if(objLista != null || objLista.size()>0){
                            
                            procesar(objLista);
                            
			} else {
				JOptionPane.showMessageDialog(null, "No se encontro registro");	
				//limpiar();
			}
		}
			
		}

/*
		if(e.getSource() == objInterfaz.btnLimpiar){
			limpiar(); 
		}
             */   
   
    
    void procesar( ArrayList<CuerpoDeAgua> objLista){
        
        try {
            
       
     
        for (CuerpoDeAgua cuerpoDeAgua : objLista) {
                objInterfaz.txtaSalidas.append(cuerpoDeAgua.getNivelRiesgo() + "\n");  
              }
         
         int contador = 0; //Se inicializa en 0 para contar cuerpos de Agua Nivel bajo o inferior
         String listaNombres = ""; //Alamacenara nombres de cuerpo de agua con Nivel Bajo
         double minIRCA = 100; //Almacenara el cuerpo con menor IRCA
         int posicion = 0; //Almacenara posision el cuerpo con menor IRCA
         String nombre = "";
         
         //Inicio del for
         for (CuerpoDeAgua cuerpoDeAgua : objLista) {
             
             Double nivelRiesgo = cuerpoDeAgua.getIrca();
             
             //Validamos cuerpos de de Agua nivel es Medio o Inferior
             if (nivelRiesgo <= 35){
                 
                  //Actuliza variable contador si cuerpos de Agua nivel es Medio o Inferior
                  contador = contador + 1;  
                  
                  
                 if (cuerpoDeAgua.getNivelRiesgo()=="MEDIO") {
                    //Solo guadamos los nombre de Cuerpos de Agua nivel MEDIO
                    listaNombres = listaNombres + cuerpoDeAgua.getNombre()+ "\n" ;  
                    }
                
             } 
             
             //Validamos IRCA mas Baja encontrada
             if (cuerpoDeAgua.getIrca() < minIRCA ){
                  minIRCA = cuerpoDeAgua.getIrca();
                  posicion = cuerpoDeAgua.getNumeroID();
                  nombre = cuerpoDeAgua.getNombre();
             }  
        }
       
         objInterfaz.txtaSalidas.append("" + contador + "\n");
        
        
        if (listaNombres==""){
            objInterfaz.txtaSalidas.append("NA" + "\n");   
        }else{
         
         objInterfaz.txtaSalidas.append(listaNombres);    
           
        }
        
        objInterfaz.txtaSalidas.append(nombre + " " + posicion + "\n");
        
        
    } catch (Exception e) {
        }
    }
    
    private void deshabilita(boolean estado){
      objInterfaz.txtNombre_Buscar_Rest.setEnabled(estado);
      objInterfaz.txtID_Buscar_Rest.setEnabled(estado);
      objInterfaz.txtMunicipio_Buscar_Rest.setEnabled(estado);
      objInterfaz.txtTipoCuerpoAgua_Buscar_Rest.setEnabled(estado);
      objInterfaz.txtTipoAgua_Buscar_Rest.setEnabled(estado);
      objInterfaz.txtIRCA_Rest.setEnabled(estado);
    }
    
    private void limpiar(){
      objInterfaz.txtNombre.setText("");
      objInterfaz.txtID.setText("");
      objInterfaz.txtMunicipio.setText("");
      objInterfaz.txtTipoCuerpoAgua.setText("");
      objInterfaz.txtTipoAgua.setText("");
      objInterfaz.txtIRCA.setText("");
    }
    
}
