/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author
 */
public abstract class ObjetoGeografico {
  private String tipoDuerpoAgua;
  private String tipoAgua;
  private int idMunicipio;
  private String municipio;

    public int getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }
  

    public String getTipoDuerpoAgua() {
        return tipoDuerpoAgua;
    }

    public void setTipoDuerpoAgua(String tipoDuerpoAgua) {
        this.tipoDuerpoAgua = tipoDuerpoAgua;
    }

    public String getTipoAgua() {
        return tipoAgua;
    }

    public void setTipoAgua(String tipoAgua) {
        this.tipoAgua = tipoAgua;
    }
  
  
 
}
