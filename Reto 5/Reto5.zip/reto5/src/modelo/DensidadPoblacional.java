/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author ContaIPUC
 */
public class DensidadPoblacional extends ObjetoGeografico{
    //Atirbutos
    private int densidadPoblacional;
    private int nivelAfentacion;
    private int idMunicipio;

    public DensidadPoblacional(int densidadPoblacional, int idMunicipio, String municpio) {
        super.setIdMunicipio(idMunicipio);
        super.setMunicipio(municpio);
        this.densidadPoblacional = densidadPoblacional;
        this.idMunicipio = idMunicipio;
        this.nivelAfentacion = afeccion(densidadPoblacional);
    }

    public int getDensidadPoblacional() {
        return densidadPoblacional;
    }

    public void setDensidadPoblacional(int densidadPoblacional) {
        this.densidadPoblacional = densidadPoblacional;
    }

    public int getNivelAfentacion() {
        return nivelAfentacion;
    }

    public void setNivelAfentacion(int nivelAfentacion) {
        this.nivelAfentacion = nivelAfentacion;
    }

    public int getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }
    
    private int afeccion(int densidadpoblacion){
        int nivel =0;
        if (densidadpoblacion < 10000){
               nivel = 0;
        }
        if (densidadpoblacion >= 10000  && densidadpoblacion <= 50000){
               nivel = 1;
        }
        if (densidadpoblacion > 50000){
               nivel = 2;
        }
        
        return nivel;
    }
    
}
