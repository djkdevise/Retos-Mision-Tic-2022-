/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reto5;

import controlador.controladorapp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import modelo.CuerpoDeAgua;
import vistas.Interfaz;

/**
 *
 * @author
 */
public class Principal {
  //Variables
  static Interfaz objVentana = new Interfaz();
  static ArrayList<CuerpoDeAgua> objLista = new ArrayList<CuerpoDeAgua>();
  static controladorapp control = null;

  
    public static void main (String[]argd){
     control = new controladorapp(objVentana, objLista);
     control.iniciar();
          
       
    }
    
   
   
   
}
