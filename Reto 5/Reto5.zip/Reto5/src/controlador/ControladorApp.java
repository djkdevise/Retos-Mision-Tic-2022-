/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import modelo.CuerpoDeAgua;
import modelo.DensidadPoblacional;
import vistas.Interfaz;

/**
 *
 * @author ContaIPUC
 */
public class ControladorApp implements ActionListener {
   //Variables
  private Interfaz objVentana = new Interfaz();
  private ArrayList<CuerpoDeAgua> objLista = new ArrayList<CuerpoDeAgua>();
  private ArrayList<DensidadPoblacional> objListaAfectaciones = new ArrayList<DensidadPoblacional>();
  
  public ControladorApp(Interfaz objInterfaz) {
      this.objVentana = objInterfaz;
  }
  
  public void iniciar(){
      objVentana.setVisible(true);
      objVentana.btnIngresar.addActionListener(this);
      objVentana.btnProcesar.addActionListener(this);
      objVentana.btnIngresarDensidad.addActionListener(this);
      objVentana.btnProcesarAfectacion.addActionListener(this);
  }
  
  
  
  private void procesar(){
        
             
        for (CuerpoDeAgua cuerpoDeAgua : objLista) {
                objVentana.txtaSalidas.append(cuerpoDeAgua.getNivelRiesgo() + "\n");  
              }
         
         int contador = 0; //Se inicializa en 0 para contar cuerpos de Agua Nivel bajo o inferior
         String listaNombres = ""; //Alamacenara nombres de cuerpo de agua con Nivel Bajo
         double minIRCA = 100; //Almacenara el cuerpo con menor IRCA
         int posicion = 0; //Almacenara posision el cuerpo con menor IRCA
         
         //Inicio del for
         for (CuerpoDeAgua cuerpoDeAgua : objLista) {
             
             Double nivelRiesgo = cuerpoDeAgua.getIrca();
             
             //Validamos cuerpos de de Agua nivel es Medio o Inferior
             if (nivelRiesgo <= 35){
                 
                  //Actuliza variable contador si cuerpos de Agua nivel es Medio o Inferior
                  contador = contador + 1;  
                  
                  
                 if (cuerpoDeAgua.getNivelRiesgo()=="MEDIO") {
                    //Solo guadamos los nombre de Cuerpos de Agua nivel MEDIO
                    listaNombres = listaNombres + cuerpoDeAgua.getNombre()+ "\n" ;  
                    }
                
             } 
             
             //Validamos IRCA mas Baja encontrada
             if (cuerpoDeAgua.getIrca() < minIRCA ){
                  minIRCA = cuerpoDeAgua.getIrca();
                  posicion = cuerpoDeAgua.getNumeroID();
             }  
        }
       
         objVentana.txtaSalidas.append("" + contador + "\n");
        
        
        if (listaNombres==""){
            objVentana.txtaSalidas.append("NA" + "\n");   
        }else{
         
         objVentana.txtaSalidas.append(listaNombres);    
           
        }
        
        objVentana.txtaSalidas.append(objLista.get(posicion).getNombre() + " " + objLista.get(posicion).getNumeroID() + "\n");
        
        
   
    }
  
   private void procesarAfectacion(){
       
       
       String nombre = "";
       
       
        
       for (DensidadPoblacional objDensidad : objListaAfectaciones) {
           
           
           for (CuerpoDeAgua cuerpoDeAgua : objLista) {
             if (cuerpoDeAgua.getNumeroID() == objDensidad.getIdCuerpoAgua())
                nombre = cuerpoDeAgua.getNombre();
              }
           
            objVentana.txtaSalidasAfectaciones.append(objDensidad.getIdCuerpoAgua() + " " + nombre + " " + objDensidad.getNivelAfentacion() + "\n");
         
           }
        }
         
    
   
 
   
    private void limpiar(){
      objVentana.txtNombre.setText("");
      objVentana.txtID.setText("");
      objVentana.txtMunicipio.setText("");
      objVentana.txtTipoCuerpoAgua.setText("");
      objVentana.txtTipoAgua.setText("");
      objVentana.txtIRCA.setText("");
    }
   
   
  


    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == objVentana.btnIngresar){
        objVentana.txtaEntrada.append(objVentana.txtNombre.getText() + " " + objVentana.txtID.getText() + " " + objVentana.txtMunicipio.getText() + " " + objVentana.txtTipoCuerpoAgua.getText() + " " + objVentana.txtTipoAgua.getText() + " " + objVentana.txtIRCA.getText() + "\n");
        CuerpoDeAgua objCuerpoAgua = new CuerpoDeAgua(objVentana.txtNombre.getText(), Integer.parseInt(objVentana.txtID.getText()), objVentana.txtMunicipio.getText(), objVentana.txtTipoCuerpoAgua.getText(), objVentana.txtTipoAgua.getText(), Double.parseDouble(objVentana.txtIRCA.getText()));
        objLista.add(objCuerpoAgua);
	limpiar(); 
	}
        
        if(e.getSource() == objVentana.btnProcesar){
        procesar();
	limpiar(); 
	}
        
         if(e.getSource() == objVentana.btnIngresarDensidad){
        DensidadPoblacional objDensidad = new DensidadPoblacional(Integer.parseInt(objVentana.txtDensidadPoblacional.getText()),Integer.parseInt(objVentana.txtIDDensidad.getText()));
        objListaAfectaciones.add(objDensidad);
         
        String nombre = "";
        
         for (CuerpoDeAgua cuerpoDeAgua : objLista) {
             if (cuerpoDeAgua.getNumeroID() == Integer.parseInt(objVentana.txtIDDensidad.getText()))
                nombre = cuerpoDeAgua.getNombre();
              }
         objVentana.txtaEntradaDensidades.append(objVentana.txtIDDensidad.getText() + " " + nombre + " " + objVentana.txtDensidadPoblacional.getText() + "\n");
        
        
	limpiar(); 
	}
        
        if(e.getSource() == objVentana.btnProcesarAfectacion){
        procesarAfectacion();
	limpiar(); 
	}
    }

    
  
  
}
