/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author ContaIPUC
 */
public class DensidadPoblacional extends ObjetoGeografico{
    private int densidadPoblacional;
    private int nivelAfentacion;
    private int idCuerpoAgua;

    public DensidadPoblacional(int densidadPoblacional,  int idCuerpoAgua) {
        super();
        this.idCuerpoAgua = idCuerpoAgua;
        this.densidadPoblacional = densidadPoblacional;
        this.nivelAfentacion = afeccion(densidadPoblacional);
    }

    public int getIdCuerpoAgua() {
        return idCuerpoAgua;
    }

    public void setIdCuerpoAgua(int idCuerpoAgua) {
        this.idCuerpoAgua = idCuerpoAgua;
    }

    

    public int getDensidadPoblacional() {
        return densidadPoblacional;
    }

    public void setDensidadPoblacional(int densidadPoblacional) {
        this.densidadPoblacional = densidadPoblacional;
    }

    public int getNivelAfentacion() {
        return nivelAfentacion;
    }

    public void setNivelAfentacion(int nivelAfentacion) {
        this.nivelAfentacion = nivelAfentacion;
    }
  
    
    private int afeccion(int densidadPoblacional){
        int nivelafectacion=0;
        
        if (densidadPoblacional < 10000){
            nivelafectacion = 0;
        }
        
         if (densidadPoblacional >= 10000 && densidadPoblacional <= 50000 ){
            nivelafectacion = 1;
        }
         
        
         if (densidadPoblacional > 50000 ){
            nivelafectacion = 2;
        }
        
      
        
        return nivelafectacion;
    }
    
    
    
    
    
    
}
