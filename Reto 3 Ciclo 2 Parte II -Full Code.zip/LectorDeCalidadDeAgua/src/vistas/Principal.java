/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import modelo.CuerpoDeAgua;

/**
 *
 * @author ContaIPUC
 */
public class Principal {
  //Variables
  static Interfaz objVentana = new Interfaz();
  static ArrayList<CuerpoDeAgua> objLista = new ArrayList<CuerpoDeAgua>();
  
    public static void main (String[]argd){
      objVentana.setVisible(true);
      
          
         
     
        ActionListener clicBtnIngresar = new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
             objVentana.txtaEntrada.append(objVentana.txtNombre.getText() + " " + objVentana.txtID.getText() + " " + objVentana.txtMunicipio.getText() + " " + objVentana.txtTipoCuerpoAgua.getText() + " " + objVentana.txtTipoAgua.getText() + " " + objVentana.txtIRCA.getText() + "\n");
             CuerpoDeAgua objCuerpoAgua = new CuerpoDeAgua(objVentana.txtNombre.getText(), Integer.parseInt(objVentana.txtID.getText()), objVentana.txtMunicipio.getText(), objVentana.txtTipoCuerpoAgua.getText(), objVentana.txtTipoAgua.getText(), Double.parseDouble(objVentana.txtIRCA.getText()));
             objLista.add(objCuerpoAgua);
             limpiar();
          }
        };
      
     
        ActionListener clicBtnProcesar = new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
                objVentana.txtaSalidas.setText("");
                procesar();
               
             }
        };
      
        
        objVentana.btnIngresar.addActionListener(clicBtnIngresar);
        objVentana.btnProcesar.addActionListener(clicBtnProcesar);
    }
    
   
    static void procesar(){
        
             
        for (CuerpoDeAgua cuerpoDeAgua : objLista) {
                objVentana.txtaSalidas.append(cuerpoDeAgua.getNivelRiesgo() + "\n");  
              }
         
         int contador = 0; //Se inicializa en 0 para contar cuerpos de Agua Nivel bajo o inferior
         String listaNombres = ""; //Alamacenara nombres de cuerpo de agua con Nivel Bajo
         double minIRCA = 100; //Almacenara el cuerpo con menor IRCA
         int posicion = 0; //Almacenara posision el cuerpo con menor IRCA
         
         //Inicio del for
         for (CuerpoDeAgua cuerpoDeAgua : objLista) {
             
             Double nivelRiesgo = cuerpoDeAgua.getIrca();
             
             //Validamos cuerpos de de Agua nivel es Medio o Inferior
             if (nivelRiesgo <= 35){
                 
                  //Actuliza variable contador si cuerpos de Agua nivel es Medio o Inferior
                  contador = contador + 1;  
                  
                  
                 if (cuerpoDeAgua.getNivelRiesgo()=="MEDIO") {
                    //Solo guadamos los nombre de Cuerpos de Agua nivel MEDIO
                    listaNombres = listaNombres + cuerpoDeAgua.getNombre()+ " " ;  
                    }
                
             } 
             
             //Validamos IRCA mas Baja encontrada
             if (cuerpoDeAgua.getIrca() < minIRCA ){
                  minIRCA = cuerpoDeAgua.getIrca();
                  posicion = cuerpoDeAgua.getNumeroID();
             }  
        }
       
         objVentana.txtaSalidas.append("" + contador + "\n");
        
        
        if (listaNombres==""){
            objVentana.txtaSalidas.append("NA" + "\n");   
        }else{
         
         objVentana.txtaSalidas.append(listaNombres  + "\n");    
           
        }
        
        objVentana.txtaSalidas.append(objLista.get(posicion).getNombre() + " " + objLista.get(posicion).getNumeroID() + "\n");
        
        
   
    }
   
    
   
    static void limpiar(){
      objVentana.txtNombre.setText("");
      objVentana.txtID.setText("");
      objVentana.txtMunicipio.setText("");
      objVentana.txtTipoCuerpoAgua.setText("");
      objVentana.txtTipoAgua.setText("");
      objVentana.txtIRCA.setText("");
    }
   
   
}
